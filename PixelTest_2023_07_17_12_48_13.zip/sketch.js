var pNIncrement = 0.01;
function setup() {
  createCanvas(320, 240);
  pixelDensity(1);
}

function draw() {
  background(255);
  loadPixels();
  
  var yoff = pNIncrement;
  for (var y = 0; y < height; y++) {
    var xoff = 0;
    for (var x = 0; x < width; x++) {
      var index = (x+ y*width)*4;
      //var rValue = random(255);
      var h = noise(xoff, yoff) * 255;
      xoff += pNIncrement;
      
      pixels[index + 0] = h;
      pixels[index + 1] = h;
      pixels[index + 2] = h;
      pixels[index + 3] = 255;
    }
    yoff += pNIncrement;
  }
  
  updatePixels();
  //noLoop();
}